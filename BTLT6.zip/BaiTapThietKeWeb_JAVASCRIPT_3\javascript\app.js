$(function () {
  $("#insertButton").on("click", function () {
    const table = document.getElementById("sampleTable");
    const row = table.insertRow(-1);
    row.insertCell(0).textContent = "New cell1";
    row.insertCell(1).textContent = "New cell2";
  });
});