$(function () {
  const form = document.getElementById("registrationForm");
  const message = document.getElementById("formMessage");
  const requiredFields = Array.from(form.querySelectorAll("[required]"));

  function setError(field, text) {
    const error = document.getElementById(`${field.id}Error`);
    error.textContent = text;
    field.setAttribute("aria-invalid", text ? "true" : "false");
  }

  function isValidDate(value) {
    const match = value.match(/^(\d{1,2})([/-])(\d{1,2})\2(\d{4})$/);
    if (!match) return false;

    const month = Number(match[1]);
    const day = Number(match[3]);
    const year = Number(match[4]);
    if (month < 1 || month > 12 || year < 1 || year >= new Date().getFullYear()) return false;

    const daysInMonth = new Date(year, month, 0).getDate();
    return day >= 1 && day <= daysInMonth;
  }

  $(form).on("submit", function (event) {
    event.preventDefault();
    let valid = true;

    requiredFields.forEach(function (field) {
      const value = field.value.trim();
      let error = value ? "" : "Trường này không được để trống.";

      if (!error && field.name === "email") {
        const emailPattern = /^[^@.\s]+(?:\.[^@.\s]+)?@[^@.\s]+(?:\.[^@.\s]+)+$/;
        if (!emailPattern.test(value)) {
          error = "Email cần đúng một dấu @, tên account tối đa một dấu chấm và domain có dấu chấm.";
        }
      } else if (!error && field.name === "dob" && !isValidDate(value)) {
        error = "Ngày sinh không hợp lệ. Dùng mm/dd/yyyy hoặc mm-dd-yyyy; năm phải nhỏ hơn năm hiện tại.";
      } else if (!error && field.name === "zip" && !/^\d{5}$/.test(value)) {
        error = "Zip code phải gồm đúng 5 chữ số.";
      }

      setError(field, error);
      if (error) valid = false;
    });

    if (valid) {
      message.textContent = "Thông tin hợp lệ. Đăng ký hoàn tất.";
      message.className = "success";
    } else {
      message.textContent = "Vui lòng kiểm tra các thông tin được đánh dấu.";
      message.className = "error";
      const firstInvalid = form.querySelector('[aria-invalid="true"]');
      if (firstInvalid) firstInvalid.focus();
    }
  });

  $(form).on("reset", function () {
    window.setTimeout(function () {
      requiredFields.forEach(function (field) {
        setError(field, "");
      });
      message.textContent = "";
      message.className = "";
    }, 0);
  });
});