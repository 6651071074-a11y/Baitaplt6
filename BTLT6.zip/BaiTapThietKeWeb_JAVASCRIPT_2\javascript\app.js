$(function () {
  $("#form1").on("submit", function (event) {
    event.preventDefault();
    const firstName = this.elements.namedItem("fname").value.trim();
    const lastName = this.elements.namedItem("lname").value.trim();
    window.alert(`Họ và tên: ${firstName} ${lastName}`);
  });
});