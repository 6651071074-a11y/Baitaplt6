$(function () {
  $("#redirectForm").on("submit", function (event) {
    event.preventDefault();
    const destination = document.getElementById("destination").value.trim();
    const message = document.getElementById("message");
    let target;

    try {
      target = new URL(destination);
    } catch {
      message.textContent = "Vui lòng nhập một đường link hợp lệ (http hoặc https).";
      return;
    }

    if (target.protocol !== "http:" && target.protocol !== "https:") {
      message.textContent = "Chỉ chấp nhận đường link bắt đầu bằng http:// hoặc https://.";
      return;
    }

    message.textContent = "";
    if (window.confirm(`Bạn có muốn chuyển đến ${target.href} không?`)) {
      window.location.assign(target.href);
    }
  });
});