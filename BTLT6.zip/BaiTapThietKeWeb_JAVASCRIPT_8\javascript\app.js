$(function () {
  const display = document.getElementById("display");
  let currentValue = "0";
  let storedValue = null;
  let operator = null;
  let startNewValue = false;

  function render() {
    display.textContent = currentValue;
  }

  function calculate() {
    if (operator === null || storedValue === null) return;
    const left = Number(storedValue);
    const right = Number(currentValue);
    let result;

    switch (operator) {
      case "+": result = left + right; break;
      case "-": result = left - right; break;
      case "*": result = left * right; break;
      case "/": result = right === 0 ? NaN : left / right; break;
      default: return;
    }

    currentValue = Number.isFinite(result) ? String(Number(result.toPrecision(12))) : "Không thể chia cho 0";
    storedValue = null;
    operator = null;
    startNewValue = true;
    render();
  }

  $(".keys").on("click", "button", function () {
    const number = this.dataset.number;
    const nextOperator = this.dataset.operator;
    const action = this.dataset.action;

    if (number !== undefined) {
      if (startNewValue || currentValue === "0" || currentValue === "Không thể chia cho 0") {
        currentValue = number;
        startNewValue = false;
      } else {
        currentValue += number;
      }
    } else if (action === "decimal") {
      if (startNewValue || currentValue === "Không thể chia cho 0") {
        currentValue = "0.";
        startNewValue = false;
      } else if (!currentValue.includes(".")) {
        currentValue += ".";
      }
    } else if (action === "clear") {
      currentValue = "0";
      storedValue = null;
      operator = null;
      startNewValue = false;
    } else if (action === "delete") {
      currentValue = currentValue.length > 1 ? currentValue.slice(0, -1) : "0";
    } else if (action === "equals") {
      calculate();
      return;
    } else if (nextOperator !== undefined) {
      if (operator !== null && !startNewValue) calculate();
      storedValue = currentValue;
      operator = nextOperator;
      startNewValue = true;
    }

    render();
  });
});