$(function () {
  $("#countButton").on("click", function () {
    const options = document.getElementById("colorSelect").options;
    const itemNames = Array.from(options, function (option) {
      return option.text;
    });
    window.alert(`Số mục: ${options.length}\nCác mục: ${itemNames.join(", ")}`);
  });
});