$(function () {
  $("#styleButton").on("click", function () {
    const paragraph = document.getElementById("text");
    $(paragraph).css({ fontSize: "24px", fontFamily: "Arial", color: "red" });
  });
});